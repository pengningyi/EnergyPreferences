# Energy Preferences

This repo is for Course EIV.

This repo is for visualization for energy preferences in both global and individual trends.

The final report is named as Energy-Preference.pdf

The project has been published to Tableau Cloud as below:
https://public.tableau.com/shared/BDPCNM6GH?:display_count=n&:origin=viz_share_link

